import cv2
im = cv2.imread('3x2.png')
print(im)
cv2.imwrite('resultat.png',im)
cv2.imshow("window",im)
