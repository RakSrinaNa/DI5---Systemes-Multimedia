#!/usr/bin/env python

from idlelib.PyShell import main

if __name__ == '__main__':
    main()
